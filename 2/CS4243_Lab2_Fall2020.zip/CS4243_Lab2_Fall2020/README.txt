You should install the following packages: 

python>=3.7
jupyterlab
numpy 
matplotlib 
opencv-python
scikit-learn 
scikit-image 
